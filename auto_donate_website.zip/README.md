# Auto Donate Script for Roblox

This is a simple website that provides a script for auto-donating Robux in the game "Pls Donate".

## 🚀 How to Use
1. Open the website.
2. Copy the script by clicking the "Copy Script" button.
3. Paste it into your Roblox executor and run it.
4. Press ENTER to automatically donate your available Robux.

## 📌 How to Host on GitHub Pages
1. Fork or download this repository.
2. Go to **Settings > Pages**.
3. Select **Deploy from branch** and choose the `main` branch.
4. After a few minutes, your website will be live!

Enjoy! 🎉
